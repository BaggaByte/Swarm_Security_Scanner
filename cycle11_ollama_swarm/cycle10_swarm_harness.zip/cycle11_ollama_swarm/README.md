# Cycle 11 – Ollama Multi-Agent Swarm Harness

## What This Is

A **real LLM experiment** that determines whether 5 collaborating, specialised agents discover more than a single generalist agent when reviewing the same code.

```
Phase 1: DISCOVERY   – 5 agents analyse target code in parallel (each with unique lens)
Phase 2: CHALLENGE   – 2 adversarial challengers peer-review every finding
Phase 3: VERDICT     – findings classified as confirmed / refuted / inconclusive  
Phase 4: MEASUREMENT – swarm vs single-agent comparison table
```

All findings flow through **shared SQLite memory** (`cycle11_memory.db`).

---

## Prerequisites

1. **Ollama installed** – already confirmed on your machine (v0.20.0)
2. **A model pulled** – e.g. `llama3.2`, `mistral`, `phi3`
3. **Python 3.10+** – confirmed (3.13.14)
4. **No extra pip packages needed** – uses only stdlib + aiohttp (already installed)

---

## Quick Start

### Step 1 – Start Ollama server
```powershell
# Open a NEW terminal window and run:
ollama serve
```

### Step 2 – Pull a model (first time only)
```powershell
ollama pull llama3.2
```

### Step 3 – Run the experiment
```powershell
cd cycle11_ollama_swarm

# Full experiment (5 agents + 2 challengers + single-agent baseline comparison):
python run_cycle11.py --model llama3.2 --workers 5 --baseline

# Quick test (3 agents, no baseline):
python run_cycle11.py --model llama3.2 --workers 3

# If using a different model (e.g. mistral, phi3, gemma2):
python run_cycle11.py --model mistral --workers 5 --baseline
```

---

## File Structure

```
cycle11_ollama_swarm/
├── run_cycle11.py           ← Main orchestrator (run this)
├── cycle11_memory.db        ← Shared SQLite (auto-created each run)
├── agents/
│   ├── ollama_client.py     ← Pure-stdlib Ollama REST client
│   ├── memory.py            ← Shared SQLite schema + helpers
│   └── research_agents.py   ← 5 specialised agents + challenger class
├── sandbox_target/
│   └── target_app.py        ← Code under analysis (has deliberate issues)
└── results/
    └── cycle11_results_*.json  ← Auto-saved per-run results
```

---

## The 5 Research Roles

| Agent | Focus Area |
|-------|------------|
| `auth_analyst`      | Authentication, session mgmt, token security |
| `access_control`    | RBAC, IDOR, privilege escalation |
| `input_validator`   | Path traversal, injection, input sanitisation |
| `availability_analyst` | DoS, rate limiting, pagination |
| `secrets_scanner`   | Hardcoded secrets, insecure defaults |

---

## Scaling Toward 700 Workers

The harness is built for scale. Each agent is a lightweight object; the bottleneck is Ollama throughput.

| Workers | Recommended model | Estimated time |
|---------|------------------|----------------|
| 5       | llama3.2:3b      | ~2-5 min       |
| 20      | llama3.2:3b      | ~8-15 min      |
| 100     | llama3.2:3b      | ~1-2 hrs       |
| 700     | llama3.2:3b      | ~8-12 hrs      |

To scale, pass `--workers N`. The ThreadPoolExecutor auto-parallelises. Each worker runs in a thread, calls Ollama's `/api/chat`, and writes to SQLite.

---

## Reading the Results

At the end of a run, you'll see:
```
  Metric                                    Swarm   Single
  ----------------------------------------  ------  ------
  Raw findings generated                         12     N/A
  Confirmed findings                              7       3
  Refuted findings (noise removed)                3     N/A
  Unique roles analysed                           5       1
  Elapsed seconds                              87.3     N/A

  CONCLUSION: Swarm found 4 MORE confirmed issues than single-agent.
```

Results are also saved to `results/cycle11_results_<timestamp>.json`.

---

## The Core Research Question

> **Do collaborative, specialised agents find things that a single agent misses?**

The experiment measures this directly: the same model, the same code, two conditions (swarm vs single). The only variable is agent specialisation and peer-review.
