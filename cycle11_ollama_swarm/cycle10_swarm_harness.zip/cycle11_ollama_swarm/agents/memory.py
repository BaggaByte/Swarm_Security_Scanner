"""
Cycle 11 – Shared SQLite Memory
==================================
All agents read and write to a single SQLite database.
Tables:
  findings     – raw hypotheses emitted by agents
  challenges   – adversarial challenges from challenger agents
  verdicts     – final confirmed / refuted status after challenge round
  run_meta     – high-level run statistics
"""
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).parent.parent / "cycle11_memory.db"


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    _init_schema(conn)
    return conn


def _init_schema(conn: sqlite3.Connection):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS findings (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        agent_id    TEXT NOT NULL,
        agent_role  TEXT NOT NULL,
        hypothesis  TEXT NOT NULL,
        evidence    TEXT NOT NULL,
        severity    TEXT NOT NULL DEFAULT 'unknown',
        created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS challenges (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        finding_id      INTEGER NOT NULL REFERENCES findings(id),
        challenger_id   TEXT NOT NULL,
        challenge_text  TEXT NOT NULL,
        verdict         TEXT NOT NULL DEFAULT 'pending',
        created_at      TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS verdicts (
        finding_id      INTEGER PRIMARY KEY REFERENCES findings(id),
        final_verdict   TEXT NOT NULL,  -- confirmed | refuted | inconclusive
        confirmed_by    TEXT,
        refuted_by      TEXT,
        notes           TEXT,
        resolved_at     TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS run_meta (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    """)
    conn.commit()


def record_finding(conn, agent_id: str, role: str, hypothesis: str, evidence: str, severity: str = "medium") -> int:
    now = datetime.now(timezone.utc).isoformat()
    cur = conn.execute(
        "INSERT INTO findings (agent_id, agent_role, hypothesis, evidence, severity, created_at) VALUES (?,?,?,?,?,?)",
        (agent_id, role, hypothesis, evidence, severity, now),
    )
    conn.commit()
    return cur.lastrowid


def record_challenge(conn, finding_id: int, challenger_id: str, challenge_text: str, verdict: str = "pending") -> int:
    now = datetime.now(timezone.utc).isoformat()
    cur = conn.execute(
        "INSERT INTO challenges (finding_id, challenger_id, challenge_text, verdict, created_at) VALUES (?,?,?,?,?)",
        (finding_id, challenger_id, challenge_text, verdict, now),
    )
    conn.commit()
    return cur.lastrowid


def record_verdict(conn, finding_id: int, final_verdict: str, confirmed_by: str = None, refuted_by: str = None, notes: str = ""):
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        """INSERT OR REPLACE INTO verdicts (finding_id, final_verdict, confirmed_by, refuted_by, notes, resolved_at)
           VALUES (?,?,?,?,?,?)""",
        (finding_id, final_verdict, confirmed_by, refuted_by, notes, now),
    )
    conn.commit()


def get_all_findings(conn) -> list:
    return [dict(row) for row in conn.execute("SELECT * FROM findings ORDER BY id").fetchall()]


def get_all_verdicts(conn) -> list:
    return [dict(row) for row in conn.execute(
        """SELECT f.id, f.agent_id, f.agent_role, f.hypothesis, f.severity,
                  v.final_verdict, v.notes
           FROM findings f
           LEFT JOIN verdicts v ON v.finding_id = f.id
           ORDER BY f.id"""
    ).fetchall()]


def set_meta(conn, key: str, value: str):
    conn.execute("INSERT OR REPLACE INTO run_meta (key,value) VALUES (?,?)", (key, value))
    conn.commit()


def get_meta(conn, key: str) -> str | None:
    row = conn.execute("SELECT value FROM run_meta WHERE key=?", (key,)).fetchone()
    return row["value"] if row else None
