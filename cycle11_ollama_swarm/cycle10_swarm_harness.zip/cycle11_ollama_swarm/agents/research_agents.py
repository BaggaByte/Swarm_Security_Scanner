"""
Cycle 11 – Research Agent Definitions
========================================
Five specialised agents, each with a unique system prompt / research lens.
All communicate with Ollama via OllamaClient and write findings to shared memory.
"""
import textwrap
from dataclasses import dataclass, field
from typing import Optional

from .ollama_client import OllamaClient
from .memory import record_finding, get_conn


# ---------------------------------------------------------------------------
# Role definitions
# ---------------------------------------------------------------------------

AGENT_ROLES = {
    "auth_analyst": {
        "name": "Authentication Analyst",
        "focus": "authentication, session management, credential handling, token security",
        "system": textwrap.dedent("""\
            You are a security researcher specialising in authentication and session management.
            Your job is to carefully read Python source code and identify weaknesses in:
            - Password hashing algorithms and strength
            - Token generation methods (randomness, entropy)
            - Session lifetime and revocation
            - Credential storage practices
            - Brute-force/rate-limiting controls
            For every issue you find, state: the exact line or function, why it is a problem,
            what an attacker could do, and a concise fix recommendation.
            Be precise. Do not fabricate findings. Only report what you actually see in the code."""),
    },
    "access_control": {
        "name": "Access Control Specialist",
        "focus": "authorisation, RBAC, privilege escalation, multi-tenancy",
        "system": textwrap.dedent("""\
            You are a security researcher specialising in authorisation and access control.
            Your job is to carefully read Python source code and identify weaknesses in:
            - Role-based access control (RBAC) enforcement
            - Privilege escalation paths
            - Insecure direct object references (IDOR)
            - Missing ownership checks
            - Horizontal vs vertical privilege separation
            For every issue you find, state: the exact line or function, why it is a problem,
            what an attacker could do, and a concise fix recommendation.
            Be precise. Do not fabricate findings. Only report what you actually see in the code."""),
    },
    "input_validator": {
        "name": "Input Validation Researcher",
        "focus": "injection, path traversal, input sanitisation, data validation",
        "system": textwrap.dedent("""\
            You are a security researcher specialising in input validation and injection flaws.
            Your job is to carefully read Python source code and identify weaknesses in:
            - Path traversal and directory escape
            - SQL/command injection opportunities
            - Missing input length / type validation
            - Unsafe file operations
            - Deserialization issues
            For every issue you find, state: the exact line or function, why it is a problem,
            what an attacker could do, and a concise fix recommendation.
            Be precise. Do not fabricate findings. Only report what you actually see in the code."""),
    },
    "availability_analyst": {
        "name": "Availability & DoS Researcher",
        "focus": "denial of service, resource exhaustion, rate limiting, pagination",
        "system": textwrap.dedent("""\
            You are a security researcher specialising in availability and denial-of-service.
            Your job is to carefully read Python source code and identify weaknesses in:
            - Missing pagination on list endpoints
            - Unbounded resource allocation
            - Missing rate limits
            - Expensive operations without guards
            - Infinite loop risks
            For every issue you find, state: the exact line or function, why it is a problem,
            what an attacker could do, and a concise fix recommendation.
            Be precise. Do not fabricate findings. Only report what you actually see in the code."""),
    },
    "secrets_scanner": {
        "name": "Secrets & Configuration Scanner",
        "focus": "hardcoded secrets, insecure defaults, misconfiguration, env handling",
        "system": textwrap.dedent("""\
            You are a security researcher specialising in secrets management and configuration.
            Your job is to carefully read Python source code and identify weaknesses in:
            - Hardcoded credentials, API keys, secrets
            - Insecure default configurations
            - Missing environment variable usage
            - Debug flags left in production code
            - Insecure cryptographic primitives
            For every issue you find, state: the exact line or function, why it is a problem,
            what an attacker could do, and a concise fix recommendation.
            Be precise. Do not fabricate findings. Only report what you actually see in the code."""),
    },
}

CHALLENGER_SYSTEM = textwrap.dedent("""\
    You are an adversarial peer-reviewer. Another agent has made a security finding.
    Your job is to critically evaluate whether this finding is:
    1. VALID   – the issue genuinely exists in the code as described
    2. PARTIAL – the issue exists but is overstated or the severity is wrong
    3. INVALID – the claim is incorrect, the code actually handles this, or it is not a security issue

    Respond with exactly one of: VALID, PARTIAL, or INVALID on the first line.
    Then explain your reasoning in 2-4 sentences, referencing specific code behaviour.
    Do not be lenient. Only confirm findings that are clearly supported by the code.""")


# ---------------------------------------------------------------------------
# Agent base class
# ---------------------------------------------------------------------------

@dataclass
class ResearchAgent:
    agent_id: str
    role_key: str
    client: OllamaClient
    conn: object  # sqlite3 connection

    @property
    def role_info(self) -> dict:
        return AGENT_ROLES[self.role_key]

    def _build_prompt(self, source_code: str) -> str:
        return textwrap.dedent(f"""\
            === SOURCE CODE TO ANALYSE ===
            {source_code}
            === END SOURCE CODE ===

            Analyse the above Python code through the lens of: {self.role_info['focus']}.
            List every issue you find. For each issue use this EXACT format:

            FINDING:
            Title: <short title>
            Location: <function or line>
            Problem: <what is wrong>
            Impact: <what attacker can do>
            Severity: <critical|high|medium|low>
            Fix: <concrete recommendation>
            ---

            If you find nothing relevant to your focus area, respond with: NO_FINDINGS""")

    def analyse(self, source_code: str) -> list[dict]:
        """
        Call the LLM with the source code and parse the structured findings.
        Returns list of dicts: {hypothesis, evidence, severity}
        """
        prompt = self._build_prompt(source_code)
        try:
            response = self.client.chat(
                messages=[
                    {"role": "system", "content": self.role_info["system"]},
                    {"role": "user",   "content": prompt},
                ]
            )
        except ConnectionError as e:
            return [{"hypothesis": "OLLAMA_UNAVAILABLE", "evidence": str(e), "severity": "info"}]

        if not response or "NO_FINDINGS" in response:
            return []

        return _parse_findings(response)

    def write_findings(self, findings: list[dict]) -> list[int]:
        """Write findings to shared memory. Returns list of finding IDs."""
        ids = []
        for f in findings:
            fid = record_finding(
                self.conn,
                agent_id=self.agent_id,
                role=self.role_key,
                hypothesis=f["hypothesis"],
                evidence=f["evidence"],
                severity=f.get("severity", "medium"),
            )
            ids.append(fid)
        return ids


# ---------------------------------------------------------------------------
# Challenger agent
# ---------------------------------------------------------------------------

@dataclass
class ChallengerAgent:
    agent_id: str
    client: OllamaClient
    conn: object

    def challenge(self, finding: dict, source_code: str) -> dict:
        """
        Read a finding from shared memory and issue an adversarial challenge.
        Returns {verdict: str, reasoning: str}
        """
        prompt = textwrap.dedent(f"""\
            === ORIGINAL SOURCE CODE ===
            {source_code}
            === END SOURCE CODE ===

            === FINDING TO EVALUATE ===
            Role: {finding.get('agent_role', '?')}
            Hypothesis: {finding['hypothesis']}
            Evidence: {finding['evidence']}
            Severity: {finding.get('severity', '?')}
            === END FINDING ===

            Evaluate this finding. Remember: respond VALID, PARTIAL, or INVALID on line 1.""")
        try:
            response = self.client.chat(
                messages=[
                    {"role": "system", "content": CHALLENGER_SYSTEM},
                    {"role": "user",   "content": prompt},
                ]
            )
        except ConnectionError as e:
            return {"verdict": "inconclusive", "reasoning": str(e)}

        if not response:
            return {"verdict": "inconclusive", "reasoning": "Empty response from LLM"}

        lines = response.strip().splitlines()
        first_line = lines[0].strip().upper() if lines else ""
        verdict = "confirmed" if "VALID" in first_line else ("refuted" if "INVALID" in first_line else "inconclusive")
        reasoning = " ".join(lines[1:]).strip() if len(lines) > 1 else response
        return {"verdict": verdict, "reasoning": reasoning}


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _parse_findings(text: str) -> list[dict]:
    """Parse LLM output into structured finding dicts."""
    findings = []
    current: dict = {}

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("FINDING:"):
            if current.get("hypothesis"):
                findings.append(current)
            current = {}
        elif line.startswith("Title:"):
            current["hypothesis"] = line[6:].strip()
        elif line.startswith("Problem:"):
            current["evidence"] = line[8:].strip()
        elif line.startswith("Severity:"):
            sev = line[9:].strip().lower()
            current["severity"] = sev if sev in {"critical", "high", "medium", "low"} else "medium"
        elif line.startswith("Location:"):
            loc = line[9:].strip()
            current["evidence"] = f"[{loc}] " + current.get("evidence", "")
        elif line.startswith("Impact:"):
            impact = line[7:].strip()
            current["evidence"] = current.get("evidence", "") + f" | Impact: {impact}"
        elif line.startswith("Fix:"):
            current["evidence"] = current.get("evidence", "") + f" | Fix: {line[4:].strip()}"

    if current.get("hypothesis"):
        findings.append(current)

    return findings
