"""
Cycle 11 – Main Orchestrator
==============================
Runs the full experiment:

  Phase 1 – DISCOVERY    : 5 specialised agents analyse the target code in parallel
  Phase 2 – CHALLENGE    : 2 challenger agents adversarially review every finding
  Phase 3 – VERDICT      : findings are classified as confirmed / refuted / inconclusive
  Phase 4 – MEASUREMENT  : prints a rich summary table comparing swarm vs single-agent baselines

Usage:
  # Make sure Ollama is running first:
  #   ollama serve   (in a separate terminal)
  #   ollama pull llama3.2   (first time only)

  python run_cycle11.py [--model llama3.2] [--workers 5] [--baseline]
"""

import argparse
import concurrent.futures
import json
import sys
import textwrap
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Path setup – allow running from any CWD
# ---------------------------------------------------------------------------
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from agents.ollama_client import OllamaClient
from agents.memory import (
    get_conn, set_meta, get_all_findings, get_all_verdicts,
    record_challenge, record_verdict,
)
from agents.research_agents import (
    ResearchAgent, ChallengerAgent, AGENT_ROLES,
)

TARGET_SRC = (ROOT / "sandbox_target" / "target_app.py").read_text()
RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4, "unknown": 5}

def _colour(text: str, code: str) -> str:
    """ANSI colour if terminal supports it."""
    return f"\033[{code}m{text}\033[0m"

def _bold(t):  return _colour(t, "1")
def _green(t): return _colour(t, "32")
def _red(t):   return _colour(t, "31")
def _yellow(t):return _colour(t, "33")
def _cyan(t):  return _colour(t, "36")


def _banner(msg: str):
    width = 70
    print()
    print("=" * width)
    print(f"  {msg}")
    print("=" * width)


# ---------------------------------------------------------------------------
# Phase 1: Discovery
# ---------------------------------------------------------------------------

def run_discovery(client: OllamaClient, conn, num_workers: int) -> dict[str, list[int]]:
    """Run all specialised research agents in parallel."""
    _banner("PHASE 1: DISCOVERY  –  Agents analysing target code")

    role_keys = list(AGENT_ROLES.keys())[:num_workers]
    agent_map: dict[str, list[int]] = {}

    def _run_agent(role_key: str, idx: int):
        agent = ResearchAgent(
            agent_id=f"agent-{idx:02d}-{role_key}",
            role_key=role_key,
            client=client,
            conn=conn,
        )
        role_info = AGENT_ROLES[role_key]
        print(f"  [{idx}] {_cyan(role_info['name'])} starting …")
        t0 = time.time()
        findings = agent.analyse(TARGET_SRC)
        ids = agent.write_findings(findings)
        elapsed = time.time() - t0
        print(f"  [{idx}] {_cyan(role_info['name'])} → {_bold(str(len(findings)))} findings  ({elapsed:.1f}s)")
        return role_key, ids

    with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as pool:
        futures = {pool.submit(_run_agent, rk, i+1): rk for i, rk in enumerate(role_keys)}
        for fut in concurrent.futures.as_completed(futures):
            rk, ids = fut.result()
            agent_map[rk] = ids

    total = sum(len(v) for v in agent_map.values())
    print(f"\n  ✓ Discovery complete. Total raw findings: {_bold(str(total))}")
    return agent_map


# ---------------------------------------------------------------------------
# Phase 2: Challenge
# ---------------------------------------------------------------------------

def run_challenge(client: OllamaClient, conn) -> None:
    """Two challenger agents independently review every finding."""
    _banner("PHASE 2: CHALLENGE  –  Adversarial peer review")

    findings = get_all_findings(conn)
    if not findings:
        print("  No findings to challenge.")
        return

    challengers = [
        ChallengerAgent(agent_id="challenger-A", client=client, conn=conn),
        ChallengerAgent(agent_id="challenger-B", client=client, conn=conn),
    ]

    def _challenge_finding(finding: dict):
        results = []
        for ch in challengers:
            r = ch.challenge(finding, TARGET_SRC)
            cid = record_challenge(conn, finding["id"], ch.agent_id, r["reasoning"], r["verdict"])
            results.append(r)
        return finding["id"], results

    print(f"  Challenging {len(findings)} findings with 2 independent challengers …\n")
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(_challenge_finding, f) for f in findings]
        for fut in concurrent.futures.as_completed(futures):
            fid, results = fut.result()
            verdicts_seen = [r["verdict"] for r in results]
            icon = _green("✓") if "confirmed" in verdicts_seen else _red("✗")
            print(f"  {icon}  Finding #{fid:02d}  →  {verdicts_seen}")

    print(f"\n  ✓ Challenge round complete.")


# ---------------------------------------------------------------------------
# Phase 3: Verdict aggregation
# ---------------------------------------------------------------------------

def run_verdict_aggregation(conn) -> None:
    """Aggregate per-finding challenge results into a final verdict."""
    _banner("PHASE 3: VERDICT AGGREGATION")

    findings = get_all_findings(conn)
    for f in findings:
        rows = conn.execute(
            "SELECT challenger_id, verdict FROM challenges WHERE finding_id=?", (f["id"],)
        ).fetchall()
        verdicts = [r["verdict"] for r in rows]
        confirmed_by = [r["challenger_id"] for r in rows if r["verdict"] == "confirmed"]
        refuted_by   = [r["challenger_id"] for r in rows if r["verdict"] == "refuted"]

        if len(confirmed_by) >= 1:
            final = "confirmed"
        elif len(refuted_by) >= 2:
            final = "refuted"
        else:
            final = "inconclusive"

        record_verdict(
            conn, f["id"], final,
            confirmed_by=", ".join(confirmed_by) or None,
            refuted_by=", ".join(refuted_by) or None,
            notes=f"Challenger verdicts: {verdicts}",
        )

    confirmed = conn.execute("SELECT count(*) FROM verdicts WHERE final_verdict='confirmed'").fetchone()[0]
    refuted   = conn.execute("SELECT count(*) FROM verdicts WHERE final_verdict='refuted'").fetchone()[0]
    inconc    = conn.execute("SELECT count(*) FROM verdicts WHERE final_verdict='inconclusive'").fetchone()[0]
    print(f"  Confirmed: {_green(str(confirmed))}  |  Refuted: {_red(str(refuted))}  |  Inconclusive: {_yellow(str(inconc))}")


# ---------------------------------------------------------------------------
# Phase 4: Baseline (single-agent simulation)
# ---------------------------------------------------------------------------

def run_single_agent_baseline(client: OllamaClient) -> list[dict]:
    """
    Simulate what a single, generalist agent would find.
    Uses a broad, unfocused prompt – mirrors what most users do with 1 LLM call.
    """
    _banner("BASELINE: Single-agent (no collaboration)")

    system = textwrap.dedent("""\
        You are a general-purpose code reviewer. Review the provided Python code
        and identify any security or quality issues. List them briefly.""")
    prompt = textwrap.dedent(f"""\
        Review this Python code and list all issues:

        {TARGET_SRC}

        Format each as:
        ISSUE: <title> – <one sentence description>""")

    try:
        response = client.chat(
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.2,
        )
    except ConnectionError as e:
        print(f"  Ollama unavailable: {e}")
        return []

    issues = []
    if response:
        for line in response.splitlines():
            if line.strip().startswith("ISSUE:"):
                issues.append({"title": line.strip()[6:].strip()})

    print(f"  Single-agent found: {_bold(str(len(issues)))} issues")
    for iss in issues:
        print(f"    - {iss['title']}")
    return issues


# ---------------------------------------------------------------------------
# Phase 5: Measurement & Report
# ---------------------------------------------------------------------------

def print_report(conn, baseline_issues: list, start_time: float, model: str) -> dict:
    """Print the final measurement table and save results JSON."""
    _banner("PHASE 4: MEASUREMENT  –  Swarm vs Single-Agent")

    verdicts = get_all_verdicts(conn)
    confirmed  = [v for v in verdicts if v.get("final_verdict") == "confirmed"]
    refuted    = [v for v in verdicts if v.get("final_verdict") == "refuted"]
    inconc     = [v for v in verdicts if v.get("final_verdict") == "inconclusive"]
    all_f      = get_all_findings(conn)

    elapsed = time.time() - start_time

    # Per-role breakdown
    role_counts: dict[str, int] = {}
    for f in all_f:
        role_counts[f["agent_role"]] = role_counts.get(f["agent_role"], 0) + 1

    print(f"\n  {'Metric':<40}  {'Swarm':>8}  {'Single':>8}")
    print(f"  {'-'*40}  {'-'*8}  {'-'*8}")
    print(f"  {'Raw findings generated':<40}  {len(all_f):>8}  {'N/A':>8}")
    print(f"  {'Confirmed findings':<40}  {len(confirmed):>8}  {len(baseline_issues):>8}")
    print(f"  {'Refuted findings (noise removed)':<40}  {len(refuted):>8}  {'N/A':>8}")
    print(f"  {'Inconclusive findings':<40}  {len(inconc):>8}  {'N/A':>8}")
    print(f"  {'Unique roles analysed':<40}  {len(role_counts):>8}  {'1':>8}")
    print(f"  {'Elapsed seconds':<40}  {elapsed:>8.1f}  {'N/A':>8}")

    print(f"\n  {_bold('Confirmed findings by the swarm:')}")
    for v in sorted(confirmed, key=lambda x: SEVERITY_ORDER.get(x.get("severity",""), 5)):
        sev = v.get("severity", "?")
        colour = _red if sev in ("critical","high") else _yellow if sev=="medium" else _green
        sev_label = sev.upper().ljust(8)
        print(f"    [{colour(sev_label)}]  {v['hypothesis']}")
        if v.get("notes"):
            print(f"              {_cyan(v['notes'][:100])}")

    # Count unique hypotheses per role
    print(f"\n  {_bold('Findings per specialised role:')}")
    for role, count in role_counts.items():
        print(f"    {AGENT_ROLES.get(role, {}).get('name', role):<35} {count:>3} raw")

    # Advantage calculation
    advantage = len(confirmed) - len(baseline_issues)
    if advantage > 0:
        conclusion = f"Swarm found {advantage} MORE confirmed issues than single-agent."
        print(f"\n  {_bold(_green('CONCLUSION:'))} {conclusion}")
    elif advantage == 0:
        print(f"\n  {_bold(_yellow('CONCLUSION:'))} Swarm and single-agent found the same number.")
    else:
        print(f"\n  {_bold(_red('CONCLUSION:'))} Single-agent outperformed swarm this run.")

    # Save JSON results
    result_obj = {
        "model": model,
        "elapsed_seconds": round(elapsed, 1),
        "swarm": {
            "raw_findings": len(all_f),
            "confirmed": len(confirmed),
            "refuted": len(refuted),
            "inconclusive": len(inconc),
            "roles": role_counts,
        },
        "single_agent": {"issues_found": len(baseline_issues)},
        "advantage": advantage,
        "confirmed_findings": [
            {"hypothesis": v["hypothesis"], "role": v["agent_role"], "severity": v.get("severity")}
            for v in confirmed
        ],
    }
    out_path = RESULTS_DIR / f"cycle11_results_{int(time.time())}.json"
    out_path.write_text(json.dumps(result_obj, indent=2))
    print(f"\n  Results saved → {out_path}")

    return result_obj


# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------

def check_ollama(client: OllamaClient) -> str:
    """Verify Ollama is reachable and pick a usable model."""
    _banner("PRE-FLIGHT: Checking Ollama")
    models = client.list_models()
    if not models:
        print(_red(
            "  ERROR: Ollama is not running or has no models.\n"
            "  Fix:\n"
            "    1. Open a terminal and run:  ollama serve\n"
            "    2. Pull a model:             ollama pull llama3.2\n"
            "    3. Re-run this script."
        ))
        sys.exit(1)

    print(f"  Ollama reachable. Available models:")
    for m in models:
        print(f"    • {m}")

    if client.model not in models:
        fallback = models[0]
        print(_yellow(f"\n  Requested model '{client.model}' not found. Using '{fallback}' instead."))
        client.model = fallback
    else:
        print(f"\n  Using model: {_bold(client.model)}")

    return client.model


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Cycle 11 – Ollama Multi-Agent Swarm Experiment")
    parser.add_argument("--model",   default="llama3.2", help="Ollama model name (default: llama3.2)")
    parser.add_argument("--workers", type=int, default=5, help="Number of research agents (1-5, default: 5)")
    parser.add_argument("--baseline", action="store_true", help="Also run single-agent baseline for comparison")
    parser.add_argument("--url",     default="http://127.0.0.1:11434", help="Ollama base URL")
    args = parser.parse_args()

    print(_bold("\n  ╔══════════════════════════════════════════════════╗"))
    print(_bold(  "  ║       CYCLE 11 – COLLABORATIVE LLM SWARM        ║"))
    print(_bold(  "  ║   Multi-Agent vs Single-Agent Research Experiment ║"))
    print(_bold(  "  ╚══════════════════════════════════════════════════╝"))

    client = OllamaClient(model=args.model, base_url=args.url)
    model_used = check_ollama(client)

    # Fresh DB for this run
    db_path = ROOT / "cycle11_memory.db"
    if db_path.exists():
        db_path.unlink()
    conn = get_conn()
    set_meta(conn, "model", model_used)
    set_meta(conn, "workers", str(args.workers))

    start = time.time()

    # --- Phase 1 ---
    run_discovery(client, conn, args.workers)

    # --- Phase 2 ---
    run_challenge(client, conn)

    # --- Phase 3 ---
    run_verdict_aggregation(conn)

    # --- Baseline (optional) ---
    baseline = run_single_agent_baseline(client) if args.baseline else []

    # --- Phase 4 ---
    result = print_report(conn, baseline, start, model_used)

    conn.close()
    return result


if __name__ == "__main__":
    main()
